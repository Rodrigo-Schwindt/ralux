<?php

namespace App\Livewire\Vistas\Productos;

use Livewire\Component;
use App\Models\Producto;
use App\Models\ProductoTipo;
use App\Models\Marca;
use App\Models\Modelo;
use Livewire\Attributes\Layout;

#[Layout('layouts.public')]
class ProductosPage extends Component
{
    public $tipo_id        = null;
    public $marca_id       = null;
    public $modelo_id      = null;
    public $busqueda       = '';
    public $perPage        = 12;
    public $modelosOptions = [];

    protected $queryString = [
        'tipo_id'   => ['except' => null],
        'marca_id'  => ['except' => null],
        'modelo_id' => ['except' => null],
        'busqueda'  => ['except' => ''],
    ];

    public function updatedTipoId()
    {
        $this->modelo_id = null;
        $this->perPage   = 12;
    }

    public function updatedMarcaId()
    {
        // Solo limpiar modelo si no pertenece a la marca seleccionada
        if ($this->modelo_id) {
            $modelo = Modelo::find($this->modelo_id);
            if (!$modelo || (string) $modelo->marca_id !== (string) $this->marca_id) {
                $this->modelo_id = null;
            }
        }
        $this->perPage = 12;
    }

    public function updatedModeloId()
    {
        $this->perPage = 12;
        if ($this->modelo_id) {
            $modelo = Modelo::find($this->modelo_id);
            if ($modelo && $modelo->marca_id) {
                $this->marca_id = $modelo->marca_id;
            }
        }
    }

    public function buscar()
    {
        $this->perPage = 12;
    }

    public function limpiarFiltros()
    {
        $this->tipo_id   = null;
        $this->marca_id  = null;
        $this->modelo_id = null;
        $this->busqueda  = '';
        $this->perPage   = 12;
    }

    public function cargarMas()
    {
        $this->perPage += 12;
    }

    public function render()
    {
        $tipos = ProductoTipo::where('visible', true)
            ->when($this->marca_id, fn($q) => $q->whereHas('productos', function ($p) {
                $p->where('visible', true)
                  ->whereHas('marcas', fn($m) => $m->where('marcas.id', $this->marca_id));
            }))
            ->orderBy('descripcion_es')
            ->get();

        $marcas = Marca::where('visible', true)
            ->whereHas('productos', function ($q) {
                $q->where('visible', true)
                  ->when($this->tipo_id, fn($q) => $q->where('producto_tipo_id', $this->tipo_id));
            })
            ->orderBy('descripcion_es')
            ->get();

        $modelos = Modelo::where('visible', true)
            ->when($this->marca_id, fn($q) => $q->where('marca_id', $this->marca_id))
            ->orderBy('descripcion_es')
            ->get();

        $this->modelosOptions = $modelos
            ->filter(fn($m) => filled(trim($m->descripcion_es, '- ')))
            ->map(fn($m) => ['value' => (string) $m->id, 'label' => trim($m->descripcion_es)])
            ->values()
            ->toArray();

        $query = Producto::query()
            ->where('visible', true)
            ->when($this->tipo_id, fn($q) => $q->where('producto_tipo_id', $this->tipo_id))
            ->when($this->marca_id, fn($q) => $q->whereHas('marcas', fn($q2) => $q2->where('marcas.id', $this->marca_id)))
            ->when($this->modelo_id, fn($q) => $q->whereHas('modelos', fn($q2) => $q2->where('modelos.id', $this->modelo_id)))
            ->when($this->busqueda, function ($q) {
                $term     = $this->busqueda;
                $termNorm = preg_replace('/[-\/\s]+/', '', trim($term));
                $q->where(function ($q2) use ($term, $termNorm) {
                    $q2->where('descripcion_es', 'like', "%{$term}%")
                       ->orWhere('codigo_ralux', 'like', "%{$term}%")
                       ->orWhereHas('codigosOM', fn($q3) => $q3->where('codigo', 'like', "%{$term}%"))
                       ->orWhereHas('equivalencias', fn($q3) => $q3->where('codigo', 'like', "%{$term}%"));

                    if ($termNorm !== '') {
                        $q2->orWhereRaw("REPLACE(REPLACE(REPLACE(codigo_ralux, '-', ''), '/', ''), ' ', '') LIKE ?", ["%{$termNorm}%"])
                           ->orWhereHas('codigosOM', fn($q3) => $q3->whereRaw("REPLACE(REPLACE(REPLACE(codigo, '-', ''), '/', ''), ' ', '') LIKE ?", ["%{$termNorm}%"]))
                           ->orWhereHas('equivalencias', fn($q3) => $q3->whereRaw("REPLACE(REPLACE(REPLACE(codigo, '-', ''), '/', ''), ' ', '') LIKE ?", ["%{$termNorm}%"]));
                    }
                });
            })
            ->with(['tipo', 'imagenPrincipal', 'marcas'])
            ->orderBy('orden');

        $total    = $query->count();
        $productos = $query->take($this->perPage)->get();
        $hayMas   = $total > $this->perPage;

        return view('livewire.vistas.productos.productos', [
            'productos' => $productos,
            'tipos'     => $tipos,
            'marcas'    => $marcas,
            'modelos'   => $modelos,
            'hayMas'    => $hayMas,
            'total'     => $total,
        ]);
    }
}
