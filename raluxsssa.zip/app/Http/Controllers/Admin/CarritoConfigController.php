<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CarritoConfig;
use Illuminate\Http\Request;

class CarritoConfigController extends Controller
{
    public function index()
    {
        $config = CarritoConfig::first() ?? new CarritoConfig();
        return view('livewire.admin.carrito-config', compact('config'));
    }

    public function save(Request $request)
    {
        $request->validate([
            'informacion'   => 'nullable|string',
            'escribenos'    => 'nullable|string|max:500',
            'contado'       => 'nullable|numeric|min:0|max:100',
            'transferencia' => 'nullable|numeric|min:0|max:100',
            'corriente'     => 'nullable|numeric|min:0|max:100',
            'iva'           => 'nullable|numeric|min:0|max:100',
        ]);

        $config = CarritoConfig::first() ?? new CarritoConfig();
        $config->informacion   = $request->informacion;
        $config->escribenos    = $request->escribenos;
        $config->contado       = $request->contado ?? 0;
        $config->transferencia = $request->transferencia ?? 0;
        $config->corriente     = $request->corriente ?? 0;
        $config->iva           = $request->iva ?? 21;
        $config->save();

        return redirect()->route('admin.carrito-config')->with('success', 'Configuración guardada exitosamente');
    }
}
