@extends('layouts.admin')

@section('content')
<div class="bg-white border border-slate-200 rounded-md shadow-sm p-8 space-y-8 animate-fadeIn">
    <div class="flex items-center justify-between">
        <h2 class="text-2xl font-semibold text-slate-900">Crear Lista de Precios</h2>
        <a href="{{ route('precios.index') }}"
           class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            Volver
        </a>
    </div>

    <form action="{{ route('precios.store') }}" method="POST" enctype="multipart/form-data"
          class="bg-white border border-slate-200 rounded-md shadow-sm p-8 space-y-6">
        @csrf

        <div>
            <label class="block text-sm font-medium text-slate-700 mb-2">Nombre *</label>
            <input type="text" name="title" value="{{ old('title') }}" required placeholder="Ej: Lista de precios - Abril 2025"
                   class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('title') border-red-500 @enderror">
            @error('title')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <div class="space-y-4">
            <label class="block text-sm font-medium text-slate-700">Archivo * <span class="text-slate-400 font-normal">(PDF, XLS, XLSX)</span></label>

            <div id="placeholder-archivo"
                 class="h-32 w-full bg-slate-100 border-2 border-dashed border-slate-300 rounded-md flex items-center justify-center text-slate-500 text-sm cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition"
                 onclick="document.getElementById('file-archivo').click()">
                <div class="text-center">
                    <svg class="w-10 h-10 mx-auto mb-2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    <p>Hacer clic para seleccionar archivo</p>
                </div>
            </div>

            <div id="preview-archivo" class="hidden p-4 bg-slate-50 border border-slate-200 rounded-md flex items-center gap-3">
                <svg class="w-8 h-8 text-blue-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                <div>
                    <p class="text-sm font-medium text-slate-700" id="filename-archivo"></p>
                    <p class="text-xs text-slate-400" id="filesize-archivo"></p>
                </div>
            </div>

            <input id="file-archivo" type="file" name="archivo" accept=".pdf,.xls,.xlsx" class="hidden" required>

            <button type="button"
                    onclick="document.getElementById('file-archivo').click()"
                    class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700 transition cursor-pointer">
                Seleccionar archivo
            </button>

            @error('archivo')
                <p class="text-red-500 text-xs">{{ $message }}</p>
            @enderror
            <p class="text-xs text-slate-500">PDF, XLS, XLSX • Máx 20MB</p>
        </div>

        <div class="flex gap-4 pt-4">
            <button type="submit"
                    class="px-6 py-2.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition font-medium">
                Crear Lista de Precios
            </button>
            <a href="{{ route('precios.index') }}"
               class="px-6 py-2.5 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition font-medium">
                Cancelar
            </a>
        </div>
    </form>
</div>

<style>
@keyframes fadeIn { from { opacity:0; transform:translateY(8px) } to { opacity:1; transform:translateY(0) } }
.animate-fadeIn { animation: fadeIn .35s ease; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.getElementById('file-archivo');
    const preview   = document.getElementById('preview-archivo');
    const placeholder = document.getElementById('placeholder-archivo');
    const filename  = document.getElementById('filename-archivo');
    const filesize  = document.getElementById('filesize-archivo');

    fileInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (file) {
            filename.textContent = file.name;
            filesize.textContent = (file.size / 1024).toFixed(0) + ' kb';
            preview.classList.remove('hidden');
            placeholder.classList.add('hidden');
        }
    });
});
</script>
@endsection
