<?php

namespace App\Http\Controllers\Productos;

use App\Models\Producto;
use App\Models\ProductoImagen;
use App\Models\ProductoTipo;
use App\Http\Controllers\Controller;
use App\Exports\ProductoExport;
use App\Exports\ProductoPlantillaExport;
use App\Imports\ProductoAdminImport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class ProductoController extends Controller
{
    public function index()
    {
        $page          = request('page', 1);
        $search        = request('search', '');
        $sortField     = request('sortField', 'orden');
        $sortDirection = request('sortDirection', 'asc');
        $tipoId        = (string) request('tipo_id', '');
        $visible       = (string) request('visible', '');

        $productos = Producto::with(['tipo', 'imagenPrincipal'])
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('codigo_ralux', 'like', "%{$search}%")
                      ->orWhere('descripcion_es', 'like', "%{$search}%")
                      ->orWhere('descripcion_en', 'like', "%{$search}%");
                });
            })
            ->when($tipoId !== '', function ($query) use ($tipoId) {
                $query->where('producto_tipo_id', $tipoId);
            })
            ->when(in_array($visible, ['0', '1'], true), function ($query) use ($visible) {
                $query->where('visible', (bool) (int) $visible);
            })
            ->when($sortField === 'orden', function ($q) use ($sortDirection) {
                $q->orderByRaw("CASE WHEN (orden IS NULL OR orden = '') THEN 1 ELSE 0 END ASC")
                  ->orderBy('orden', $sortDirection);
            }, function ($q) use ($sortField, $sortDirection) {
                $q->orderBy($sortField, $sortDirection);
            })
            ->paginate(10, ['*'], 'page', $page);

        if (request()->ajax()) {
            return response()->json([
                'html'        => view('livewire.productos.partials.table', compact('productos'))->render(),
                'pagination'  => view('livewire.productos.partials.pagination', compact('productos'))->render(),
                'currentPage' => $productos->currentPage(),
                'lastPage'    => $productos->lastPage(),
                'firstItem'   => $productos->firstItem() ?? 0,
                'lastItem'    => $productos->lastItem() ?? 0,
                'total'       => $productos->total(),
            ]);
        }

        $tipos = ProductoTipo::orderBy('descripcion_es')->get();

        return view('livewire.productos.index', compact('productos', 'tipos'));
    }

    // ── EXPORTAR ──────────────────────────────────────────────────────────────

    public function exportar()
    {
        $filename = 'productos_' . now()->format('Y-m-d_His') . '.xlsx';
        return Excel::download(new ProductoExport, $filename);
    }

    public function exportarPlantilla()
    {
        return Excel::download(new ProductoPlantillaExport, 'productos_plantilla.xlsx');
    }

    // ── IMPORTAR ──────────────────────────────────────────────────────────────

    public function importar(Request $request)
    {
        $request->validate([
            'archivo' => 'required|file|mimes:xlsx,xls|max:10240',
        ], [
            'archivo.required' => 'Seleccioná un archivo para importar.',
            'archivo.mimes'    => 'El archivo debe ser Excel (.xlsx o .xls).',
            'archivo.max'      => 'El archivo no puede superar los 10 MB.',
        ]);

        try {
            Excel::import(new ProductoAdminImport, $request->file('archivo'));

            return response()->json([
                'success' => true,
                'message' => 'Importación completada correctamente.',
            ]);

        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            $errores = collect($e->failures())
                ->map(fn($f) => "Fila {$f->row()}: " . implode(', ', $f->errors()))
                ->implode(' | ');

            return response()->json(['success' => false, 'message' => $errores], 422);

        } catch (\Throwable $e) {
            return response()->json(['success' => false, 'message' => 'Error al importar: ' . $e->getMessage()], 500);
        }
    }

    // ── ELIMINAR ──────────────────────────────────────────────────────────────

    public function destroy($id)
    {
        $producto = Producto::with('imagenes')->findOrFail($id);

        // Delete media files
        foreach (['pdf', 'sonido', 'video', 'imagen_diagrama'] as $field) {
            if ($producto->$field && Storage::disk('public')->exists($producto->$field)) {
                Storage::disk('public')->delete($producto->$field);
            }
        }

        // Delete product images from storage
        foreach ($producto->imagenes as $imagen) {
            if (Storage::disk('public')->exists($imagen->ruta)) {
                Storage::disk('public')->delete($imagen->ruta);
            }
        }

        $producto->delete();

        if (request()->ajax() || request()->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Producto eliminado correctamente',
            ]);
        }

        return redirect()->route('productos.index')
            ->with('success', 'Producto eliminado correctamente');
    }

    public function destroyImagen($productoId, $imagenId)
    {
        $imagen = ProductoImagen::where('producto_id', $productoId)->findOrFail($imagenId);

        if (Storage::disk('public')->exists($imagen->ruta)) {
            Storage::disk('public')->delete($imagen->ruta);
        }

        $wasPrincipal = $imagen->principal;
        $imagen->delete();

        // If it was principal, set next available as principal
        if ($wasPrincipal) {
            $next = ProductoImagen::where('producto_id', $productoId)->orderBy('orden')->first();
            if ($next) $next->update(['principal' => true]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Imagen eliminada correctamente',
        ]);
    }

    public function setPrincipalImagen($productoId, $imagenId)
    {
        ProductoImagen::where('producto_id', $productoId)->update(['principal' => false]);
        ProductoImagen::where('producto_id', $productoId)->where('id', $imagenId)->update(['principal' => true]);

        return response()->json([
            'success' => true,
            'message' => 'Imagen principal actualizada',
        ]);
    }
}
