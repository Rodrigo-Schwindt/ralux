<?php

namespace App\Http\Controllers\Precios;

use App\Http\Controllers\Controller;
use App\Models\Precio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PrecioController extends Controller
{
    public function index()
    {
        $precios = Precio::orderBy('created_at', 'desc')->get();
        return view('livewire.precios.index', compact('precios'));
    }

    public function create()
    {
        return view('livewire.precios.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'   => 'required|string|max:255',
            'archivo' => 'required|file|mimes:pdf,xls,xlsx|max:20480',
        ]);

        $precio = new Precio();
        $precio->title   = $request->title;
        $precio->archivo = $request->file('archivo')->store('precios', 'public');
        $precio->save();

        return redirect()->route('precios.index')->with('success', 'Lista de precios creada exitosamente');
    }

    public function edit($id)
    {
        $precio = Precio::findOrFail($id);
        return view('livewire.precios.edit', compact('precio'));
    }

    public function update(Request $request, $id)
    {
        $precio = Precio::findOrFail($id);

        $request->validate([
            'title'   => 'required|string|max:255',
            'archivo' => 'nullable|file|mimes:pdf,xls,xlsx|max:20480',
        ]);

        $precio->title = $request->title;

        if ($request->hasFile('archivo')) {
            Storage::disk('public')->delete($precio->archivo);
            $precio->archivo = $request->file('archivo')->store('precios', 'public');
        }

        $precio->save();

        return redirect()->route('precios.index')->with('success', 'Lista de precios actualizada exitosamente');
    }

    public function destroy($id)
    {
        $precio = Precio::findOrFail($id);
        Storage::disk('public')->delete($precio->archivo);
        $precio->delete();

        return response()->json(['success' => true, 'message' => 'Lista de precios eliminada exitosamente']);
    }
}
