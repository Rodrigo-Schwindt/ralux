<?php

namespace App\Imports;

use App\Models\CodigoOM;
use App\Models\Producto;
use App\Models\ProductoImagen;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;

class ProductoAdminImport implements ToModel, WithHeadingRow, SkipsEmptyRows
{
    private function limpiarNumero($valor): ?string
    {
        if ($valor === null || $valor === '') return null;
        $limpio = preg_replace('/[^0-9.]/', '', (string) $valor);
        return $limpio !== '' ? $limpio : null;
    }

    private function limpiarFecha($valor): ?string
    {
        if ($valor === null || $valor === '') return null;
        $str = (string) $valor;
        if (str_starts_with($str, '-') || str_starts_with($str, '0000')) return null;
        return $str;
    }

    private function valorPresente($row, string $campo): bool
    {
        return isset($row[$campo]) && $row[$campo] !== null && $row[$campo] !== '';
    }

    public function model(array $row)
    {
        $codigo = $row['codigo_ralux'] ?? null;
        if (empty($codigo)) {
            return null;
        }

        // ── ELIMINAR ─────────────────────────────────────────────────────────
        if (isset($row['eliminar']) && (int) $row['eliminar'] === 1) {
            $producto = Producto::with('imagenes')->where('codigo_ralux', $codigo)->first();

            if ($producto) {
                // Delete associated files from storage
                foreach (['pdf', 'sonido', 'video', 'imagen_diagrama'] as $campo) {
                    if ($producto->$campo && Storage::disk('public')->exists($producto->$campo)) {
                        Storage::disk('public')->delete($producto->$campo);
                    }
                }
                foreach ($producto->imagenes as $imagen) {
                    if (Storage::disk('public')->exists($imagen->ruta)) {
                        Storage::disk('public')->delete($imagen->ruta);
                    }
                }
                $producto->delete();
            }

            return null;
        }

        // ── CREAR / ACTUALIZAR ────────────────────────────────────────────────
        // Only include fields that are actually present and non-empty in the row,
        // so existing values are preserved for blank cells (safe mode).
        $data = [];

        $camposTexto = [
            'descripcion_es', 'descripcion_en', 'safe_url', 'pdf',
            'sonido', 'video', 'imagen_diagrama',
            'caract_1', 'valor_1', 'caract_2', 'valor_2',
            'caract_3', 'valor_3', 'caract_4', 'valor_4',
            'caract_5', 'valor_5', 'caract_6', 'valor_6',
            'caract_7', 'valor_7', 'caract_8', 'valor_8',
            'caract_9', 'valor_9', 'caract_10', 'valor_10',
        ];
        foreach ($camposTexto as $campo) {
            if ($this->valorPresente($row, $campo)) {
                $data[$campo] = $row[$campo];
            }
        }

        $camposNumericos = ['precio', 'descuento', 'voltaje', 'amperaje', 'terminales'];
        foreach ($camposNumericos as $campo) {
            if ($this->valorPresente($row, $campo)) {
                $data[$campo] = $this->limpiarNumero($row[$campo]);
            }
        }

        $camposBooleanos = ['soporte', 'estado', 'destacado', 'visible'];
        foreach ($camposBooleanos as $campo) {
            if ($this->valorPresente($row, $campo)) {
                $data[$campo] = (int) $row[$campo];
            }
        }

        if ($this->valorPresente($row, 'orden')) {
            $data['orden'] = (int) $row['orden'];
        }
        if ($this->valorPresente($row, 'producto_tipo_id')) {
            $data['producto_tipo_id'] = (int) $row['producto_tipo_id'];
        }
        if ($this->valorPresente($row, 'id')) {
            $data['id'] = (int) $row['id'];
        }

        $fechaDesde = $this->limpiarFecha($row['periodo_desde'] ?? null);
        $fechaHasta = $this->limpiarFecha($row['periodo_hasta'] ?? null);
        if ($fechaDesde !== null) $data['periodo_desde'] = $fechaDesde;
        if ($fechaHasta !== null) $data['periodo_hasta'] = $fechaHasta;

        $producto = Producto::updateOrCreate(
            ['codigo_ralux' => $codigo],
            $data
        );

        // ── RELACIONES (solo si la columna no está vacía) ─────────────────────
        if ($this->valorPresente($row, 'vehiculo_tipos_ids')) {
            $ids = array_filter(array_map('intval', explode(',', (string) $row['vehiculo_tipos_ids'])));
            $producto->vehiculoTipos()->sync($ids);
        }

        if ($this->valorPresente($row, 'marcas_ids')) {
            $ids = array_filter(array_map('intval', explode(',', (string) $row['marcas_ids'])));
            $producto->marcas()->sync($ids);
        }

        if ($this->valorPresente($row, 'modelos_ids')) {
            $ids = array_filter(array_map('intval', explode(',', (string) $row['modelos_ids'])));
            $producto->modelos()->sync($ids);
        }

        // ── CÓDIGOS OM ────────────────────────────────────────────────────────
        // Format: "codigo|marca_id,codigo2|marca_id2"  (marca_id can be empty)
        if ($this->valorPresente($row, 'codigos_om')) {
            $producto->codigosOM()->delete();

            $vistos = [];
            $pares  = explode(',', (string) $row['codigos_om']);
            foreach ($pares as $par) {
                $par = trim($par);
                if ($par === '') continue;

                $partes    = explode('|', $par, 2);
                $codigo_om = trim($partes[0]);
                $marca_id  = isset($partes[1]) && $partes[1] !== '' ? (int) $partes[1] : null;
                $clave     = $codigo_om . '|' . ($marca_id ?? '');

                if ($codigo_om === '' || isset($vistos[$clave])) continue;
                $vistos[$clave] = true;

                CodigoOM::create([
                    'producto_id' => $producto->id,
                    'marca_id'    => $marca_id,
                    'codigo'      => $codigo_om,
                ]);
            }
        }

        return null;
    }
}
