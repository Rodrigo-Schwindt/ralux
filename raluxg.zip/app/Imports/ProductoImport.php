<?php

namespace App\Imports;

use App\Models\Producto;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ProductoImport implements ToModel, WithHeadingRow
{
    private function limpiarNumero($valor)
    {
        if (empty($valor)) return null;
        return preg_replace('/[^0-9.]/', '', $valor) ?: null;
    }
    private function limpiarFecha($valor)
{
    if (empty($valor)) return null;
    if (str_starts_with($valor, '-') || str_starts_with($valor, '0000')) return null;
    return $valor;
}

    public function model(array $row)
{
    if (empty($row['id'])) {
        return null;
    }

    Producto::updateOrCreate(
        ['codigo_ralux' => $row['codigo_ralux']],
        [
            'id'               => $row['id'],
            'producto_tipo_id' => $row['id_producto_tipo'],
            'descripcion_es'   => $row['descripcion_es'],
            'descripcion_en'   => $row['descripcion_en'],
            'voltaje'          => $this->limpiarNumero($row['voltaje']),
            'amperaje'         => $this->limpiarNumero($row['amperaje']),
            'terminales'       => $this->limpiarNumero($row['terminales']),
            'soporte'          => $row['soporte'] ?? 0,
'caract_1'  => $row['caract 1'] ?? null,
'valor_1'   => $row['valor 1'] ?? null,
'caract_2'  => $row['caract 2'] ?? null,
'valor_2'   => $row['valor 2'] ?? null,
'caract_3'  => $row['caract 3'] ?? null,
'valor_3'   => $row['valor 3'] ?? null,
'caract_4'  => $row['caract 4'] ?? null,
'valor_4'   => $row['valor 4'] ?? null,
'caract_5'  => $row['caract 5'] ?? null,
'valor_5'   => $row['valor 5'] ?? null,
'caract_6'  => $row['caract 6'] ?? null,
'valor_6'   => $row['valor 6'] ?? null,
'caract_7'  => $row['caract 7'] ?? null,
'valor_7'   => $row['valor 7'] ?? null,
'caract_8'  => $row['caract 8'] ?? null,
'valor_8'   => $row['valor 8'] ?? null,
'caract_9'  => $row['caract 9'] ?? null,
'valor_9'   => $row['valor 9'] ?? null,
'caract_10' => $row['caract 10'] ?? null,
'valor_10'  => $row['valor 10'] ?? null,
'pdf'       => $row['pdf'] ?? null,
            'precio'           => $this->limpiarNumero($row['precio']),
            'periodo_desde'    => $this->limpiarFecha($row['periodo_desde']),
            'periodo_hasta'    => $this->limpiarFecha($row['periodo_hasta']),
            'safe_url'         => $row['safe_url'] ?? null,
            'sonido'           => $row['sonido'] ?? null,
            'video'            => $row['video'] ?? null,
            'estado'           => $row['estado'] ?? 1,
        ]
    );

    return null;
}
}